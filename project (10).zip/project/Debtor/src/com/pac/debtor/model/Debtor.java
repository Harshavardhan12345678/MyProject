package com.pac.debtor.model;

public class Debtor {
	private String FirstName,LastName,DebtorId,AddressLine1,AddressLine2,FaxNumber,PhoneNumber,EmailId,BankName,BranchName,SwiftAddress,DebtorAccountNumber,AccountCurrency;

	

	public String getFirstName() {
		return FirstName;
	}

	public void setFirstName(String firstName) {
		FirstName = firstName;
	}

	public String getLastName() {
		return LastName;
	}

	public void setLastName(String lastName) {
		LastName = lastName;
	}

	public String getDebtorId() {
		return DebtorId;
	}

	public void setDebtorId(String debtorId) {
		DebtorId = debtorId;
	}

	public String getAddressLine1() {
		return AddressLine1;
	}

	public void setAddressLine1(String addressLine1) {
		AddressLine1 = addressLine1;
	}

	public String getAddressLine2() {
		return AddressLine2;
	}

	public void setAddressLine2(String addressLine2) {
		AddressLine2 = addressLine2;
	}

	public String getFaxNumber() {
		return FaxNumber;
	}

	public void setFaxNumber(String faxNumber) {
		FaxNumber = faxNumber;
	}

	public String getPhoneNumber() {
		return PhoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		PhoneNumber = phoneNumber;
	}

	public String getEmailId() {
		return EmailId;
	}

	public void setEmailId(String emailId) {
		EmailId = emailId;
	}

	public String getBankName() {
		return BankName;
	}

	public void setBankName(String bankName) {
		BankName = bankName;
	}

	public String getBranchName() {
		return BranchName;
	}

	public void setBranchName(String branchName) {
		BranchName = branchName;
	}

	public String getSwiftAddress() {
		return SwiftAddress;
	}

	public void setSwiftAddress(String swiftAddress) {
		SwiftAddress = swiftAddress;
	}

	public String getDebtorAccountNumber() {
		return DebtorAccountNumber;
	}

	public void setDebtorAccountNumber(String debtorAccountNumber) {
		DebtorAccountNumber = debtorAccountNumber;
	}
	public String getAccountCurrency() {
		return AccountCurrency;
	}

	public void setAccountCurrency(String accountCurrency) {
		AccountCurrency = accountCurrency;
	}

}