package com.pac.debtor.model;

import java.sql.Date;
import java.text.SimpleDateFormat;

public class IdUtil {

	public static String generateId() {
		String pId = null;
		
		SimpleDateFormat sdf=new SimpleDateFormat("yyyyMMddhhmmss");
		pId=sdf.format(new Date(0));
		pId = "P"+pId;
		
		return pId;
	}
	
	
	public static String generatetransactionReference() {
		// TODO Auto-generated method stub
		
String tId = null;
		
		SimpleDateFormat sdf=new SimpleDateFormat("yyyyMMddhhmmss");
		tId=sdf.format(new Date(0));
		tId = "T"+tId;
		
		return tId;
	}

	
}
