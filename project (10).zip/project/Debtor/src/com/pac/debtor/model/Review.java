package com.pac.debtor.model;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;



import java.sql.Timestamp;

import com.pac.debtor.*;



public class Review implements Serializable{
	private String TransactionReference;
	private String Status;
	private Timestamp DateTime;
	private String TransactionInformation;
	
	public Review() {
		super();
		TransactionReference = IdUtil.generatetransactionReference();
		SimpleDateFormat sdf=new SimpleDateFormat("YYYY-MM-DD hh:mm:ss");	
		Timestamp timestamp=new Timestamp(System.currentTimeMillis());
		sdf.format(timestamp);
		DateTime = timestamp;
	}
	
	public Review(String status,String transactioninformation) {
		super();
		Status = status;
		TransactionInformation = transactioninformation;
		
		TransactionReference = IdUtil.generatetransactionReference();
		
		SimpleDateFormat sdf=new SimpleDateFormat("YYYY-MM-DD hh:mm:ss");
		
		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		
		sdf.format(timestamp);
		
		//System.out.println(timestamp);
		
		DateTime = timestamp;
		
	}



	public Review(String transactionReference, String status, String transactionInformation) {
		super();
		TransactionReference = transactionReference;
		Status = status;
		TransactionInformation = transactionInformation;
		
		SimpleDateFormat sdf=new SimpleDateFormat("YYYY-MM-DD hh:mm:ss");
		
		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		
		sdf.format(timestamp);
		
		DateTime = timestamp;
	}



	public Review(String status, Timestamp dateTime, String transactionInformation) {
		super();
		Status = status;
	    DateTime = dateTime;
		TransactionReference = IdUtil.generatetransactionReference();
		TransactionInformation = transactionInformation;
	}

	public Review(String transactionReference, String status, Timestamp dateTime, String transactionInformation) {
		super();
		TransactionReference = transactionReference;
		Status = status;
		DateTime = dateTime;
		TransactionInformation =transactionInformation;

	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	public String getTransactionReference() {
		return TransactionReference;
	}
	public void setTransactionReference(String transactionReference) {
		TransactionReference = transactionReference;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	public Date getDateTime() {
		return DateTime;
	}
	public void setDateTime(Timestamp dateTime) {
		DateTime = dateTime;
	}
	public String getTransactionInformation() {
		return TransactionInformation;
	}
	public void setTransactionInformation(String transactionInformation) {
		TransactionInformation = transactionInformation;
	}
	

	
	
	
	
	
	
	
	
	
	
	
}
