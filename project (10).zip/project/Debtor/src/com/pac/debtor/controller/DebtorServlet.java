package com.pac.debtor.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pac.debtor.dao.DebtorDao;
import com.pac.debtor.model.Debtor;


/**
 * Servlet implementation class DebtorServlet
 */
@WebServlet("/DebtorServlet")
public class DebtorServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	  
		DebtorDao debDao=new DebtorDao();
    public DebtorServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void dopostt(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		String action=request.getParameter("action");
		System.out.println(action);
		switch(action)
		{
		case "add":
			insert(request,response);
		    break;
		
		}
	}


	protected void insert(HttpServletRequest request, HttpServletResponse response) throws IOException {
		Debtor  debtor=new Debtor();

		debtor.setFirstName(request.getParameter("firstName"));
		debtor.setLastName(request.getParameter("lastName"));
		debtor.setDebtorId(request.getParameter("debtorId"));
		debtor.setAddressLine1(request.getParameter("addressLine1"));
		debtor.setAddressLine2(request.getParameter("addressline2"));
		debtor.setFaxNumber(request.getParameter("faxnumber"));
		debtor.setPhoneNumber(request.getParameter(" phoneNumber"));
		debtor.setEmailId(request.getParameter("emailId"));
		debtor.setBankName(request.getParameter("bankName"));
		debtor.setBranchName(request.getParameter("branchName"));
		debtor.setSwiftAddress(request.getParameter("swiftAddress"));
		debtor.setDebtorAccountNumber(request.getParameter("debtorAccountNumber"));
		debtor.setAccountCurrency(request.getParameter("accountCurrency"));

				 
		int i=debDao.save(debtor);
		if(i>0){
		response.sendRedirect("rev.jsp");
		}  
		   else{ 
			   
			   response.sendRedirect("adduser-error.jsp");
		 
		}
		}
		 
		// TODO Auto-generated method stub
		
	}

	






 