package com.pac.debtor.dao;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import com.pac.debtor.model.Debtor;

public class DebtorDao {
	public   int save(Debtor u){
		int status=0;
		try{
			Connection con=MySqlConn.getCon();
			PreparedStatement ps=con.prepareStatement("insert into debtordetails(FirstName,LastName,DebtorId,AddressLine1,AddressLine2,FaxNumber,PhoneNumber,EmailId,BankName,BranchName,SwiftAddress,DebtorAccountNumber,AccountCurrency)  values(?,?,?,?,?,?,?,?,?,?,?,?,?)");
		 
			ps.setString(1,u.getFirstName());
		 	ps.setString(2,u.getLastName());
			ps.setString(3,u.getDebtorId());
			ps.setString(4,u.getAddressLine1());
			ps.setString(5,u.getAddressLine2());
		 	ps.setString(6,u.getFaxNumber());
			ps.setString(7,u.getPhoneNumber());
			ps.setString(8,u.getEmailId());
			ps.setString(9,u.getBankName());
		 	ps.setString(10,u.getBranchName());
			ps.setString(11,u.getSwiftAddress());
			ps.setString(12,u.getDebtorAccountNumber());
			ps.setString(13,u.getAccountCurrency());
			status=ps.executeUpdate();
		}catch(Exception e)
		{
			System.out.println(e);
		}
		return status;
		
		
	}

}


