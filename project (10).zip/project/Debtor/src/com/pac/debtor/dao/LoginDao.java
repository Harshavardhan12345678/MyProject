package com.pac.debtor.dao;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.pac.debtor.dao.MySqlConn;
import com.pac.debtor.model.Login;

import java.sql.Connection;
import java.sql.DriverManager;


public class LoginDao {
	public static Login save(String username, String password) throws SQLException, 
	ClassNotFoundException {
String jdbcURL = "jdbc:mysql://localhost:3305/debtor";
String dbUser = "root";
String dbPassword = "Sivapriya1@";

Class.forName("com.mysql.jdbc.Driver");
Connection connection = DriverManager.getConnection(jdbcURL, dbUser, dbPassword);
String sql = "SELECT * FROM login WHERE username = ? and password = ?";
PreparedStatement statement = connection.prepareStatement(sql);
statement.setString(1, username);
statement.setString(2, password);

ResultSet result = statement.executeQuery();

Login log = null;

if (result.next()) {
	log = new Login();
	log.setUsername(username);
}

connection.close();

return log;
}
}
